//el parametro provincia le corresponde al id que envia el combo de provincia 
function consultarCiudades(provincia){
//se crea un objeto para poder hacer una consulta al servidor 
	request = new XMLHttpRequest();
//cuando cambia readystate se ejecuta la funcion de abajo	
	request.onreadystatechange=function(){
		//BUSCAR INFORMACION
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById('ciudades').innerHTML=this.responseText;
		}
	}
	//"provincia" es el parametro de la primera funcion 
	request.open('GET','consultarCiudades.php?provincia='+provincia,true);
	request.send();
}
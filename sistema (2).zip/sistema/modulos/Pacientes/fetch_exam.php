<?php
require('../../php/conexion.php');

$query="SELECT*FROM exam_auxiliar ORDER BY id_exam_aux DESC";

$rs_query=mysqli_query($conexion,$sql);

$listadoIm='<div class="row"';

if ($rs->execute()) {
	$resultado=$rs_query->fetchAll();
	foreach($resultado as $row)
		$listadoIm.='<div class="col-md-2" style="margin-bottom:16px;"
				<img src="data:image/jpeg;base64,'.base64_encode($row["images"]).'"class="img-thumbnm"/>
			</div>
			';
}
//la funcion base64_encode toma un string y retorna datos codificados

$listadoIm.='</div>';

echo $listadoIm;

 ?>
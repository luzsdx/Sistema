<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
								<form id="hcgeneral">
							  		<div class="row text-left">
							  			<div class="col-md-2">
							  				<input type="checkbox" id="check1" class="d-none" onclick="deshabilitar(this.id)">
							  				<label for="labelChek1">¿Padre con vida?</label>
												<div class=" text-left form-inline">		
						 				 			<div class="radio1 form-inline">	
						 				 			<label class="mr-1" for="op1">Si</label>	
						 				 			<input type="radio" id="op1" name="padreVida">
						 				 			</div>
						 				 			<div class="mr-2"></div>
						 				 			<div class="radio2 form-inline">
						 				 			<label class="mr-1" for="op2">No</label>	
						 				 			<input type="radio" id="op2" name="padreVida">
						 				 			</div>
						 				 		</div>	
							  			</div>
							  				<br>
							  			<div class="col-md-4">
							  				<input type="checkbox" id="check2" class="d-none" onclick="deshabilitar(this.id)">	  
							  				<label for="LabelCheck2">Enfermedad que padece o padeció</label>
							  				<br>
							  					<input type="text" name="enfPadre" id="enfPadre" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">			  			
							  			</div>
							  			<div class="col-md-2">
							  				<input type="checkbox" id="check3" class="d-none" onclick="deshabilitar(this.id)">	
			  							<label for="LabelCheck3">¿Madre con vida?</label>
			  							<div class="form-inline">
			  								<div class="radio3 form-inline">
			  								<label class="mr-1" for="op3">Si</label>
			  								<input type="radio" id="op3" name="madreViva">
			  								</div>
			  								<div class="mr-2"></div>
			  								<div class="radio4 form-inline">
			  								<label class="mr-1" for="op4">No</label>
											<input type="radio" id="op4" name="madreViva">	
			  								</div>	
			  							</div>
			  							</div>	
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check4" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck4">Enfermedad que padece o padeció</label>
			  								<br>
							  					<input type="text" name="enfMadre" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>		  								
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-2">
			  								<input type="checkbox" id="check5" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck5">¿Hermanos?</label>
			  								<div class="form-inline">
			  									<div class="radio5 form-inline">
			  									<label class="mr-1" for="op5" >Si</label>
			  									<input type="radio" id="op5" name="hno" >
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio6 form-inline">
			  									<label class="mr-1" for="op6">No</label>
			  									<input type="radio" id="op6" name="hno">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check6" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck6">¿Sanos?</label>
			  								<input type="text" name="hnoSano" id="hnoSano" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  							<br>
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check6" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck6">¿Sufre de alguna enfermedad?</label>
			  								<div class="form-inline">
			  									<div class="radio7 form-inline">
			  									<label class="mr-1" for="op7">Si</label>	
			  									<input type="radio" id="op7" name="pacSuf">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio8 form-inline" >
			  									<label class="mr-1" for="op8">No</label>
			  									<input type="radio" id="op8" name="pacSuf">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3" id="pacEnf">
			  								<label for="labelCheck6">¿De qué?</label>
			  								<textarea name="pacEnf" id="pacEnf" class="form-control" aria-label="With textarea"></textarea>
			  							</div>
			  							
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check7" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck7">¿Hace tratamiento médico?</label>
			  								<div class="form-inline">
			  									<div class="radio9 form-inline">
			  									<label class="mr-1" for="op9">Si</label>	
			  									<input type="radio" id="op9" name="tratMedico">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio10 form-inline">
			  									<label class="mr-1" for="op10">No</label>	
			  									<input type="radio" id="op10" name="tratMedico">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3" id="tratMedico">
			  								<label for="labelCheck7">¿Cuál?</label>
			  								<input type="text" id="tratMedico" name="tratamiento" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  							<div class="col-md-6">
			  								<input type="checkbox" id="check8" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck8">¿Qué medicamento/s consume habitualmente?</label>
			  								<textarea name="medicamentos" class="form-control" aria-label="With textarea"></textarea>
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  								<div class="col-md-6">
			  									<input type="checkbox" id="check9" class="d-none" onclick="deshabilitar(this.id)">
			  									<label for="labelCheck9">¿Qué medicamentos ha consumido en los últimos 5 años?</label>
			  									<textarea name="medicamentos5" class="form-control" aria-label="With textarea"></textarea>
			  								</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check10" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck10">¿Realiza algún deporte?</label>
			  								<div class="form-inline">
			  									<div class="radio11 form-inline">
			  									<label class="mr-1" for="op11">Si</label>	
			  									<input type="radio" id="op11" name="deporte">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio12 form-inline">
			  									<label class="mr-1" for="op12">No</label>
			  									<input type="radio" id="op12" name="deporte">
			  									</div>
			  								</div>					
			  							</div>
			  							<div class="col-md-3 malestar">
			  								<label for="labelCheck10">¿Nota algún malestar al realizarlo?</label>
			  								<div class="form-inline">
			  									<div class="radio13 form-inline">
			  									<label class="mr-1" for="op13">Si</label>	
			  									<input type="radio" class="malestar" id="op13" name="malestar">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio14 form-inline">
			  									<label class="mr-1" for="14" >No</label>	
			  									<input type="radio" class="malestar" id="op14" name="malestar">
			  									</div>
			  								</div>
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-5">
			  								<input type="checkbox" id="check11" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck11">Cuando le sacan una muela, ¿cicatriza bien?</label>
			  								<input type="text" name="muelaCicatriza" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  							<div class="col-md-2">
			  								<label for="labelCheck12">¿Sangra mucho?</label>
			  								<input type="text" name="sangraMucho" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div> 
			  							<div class="col-md-5">
			  								<input type="checkbox" id="check13" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck13">¿Tiene problema de colágeno (hiperlaxitud)?</label>
			  								<div class="form-inline">
			  									<div class="radio15 form-inline">
			  									<label class="mr-1" for="op15">Si</label>		
			  									<input type="radio" id="op15" name="colageno">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio16 form-inline">
			  									<label class="mr-1" for="op16">No</label>
			  									<input type="radio" id="op16" name="colageno">
			  									</div>
			  								</div>			 				
			  							</div>
			  					</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check14" class="d-none" onclick="deshabilitar(this.id)">
			  								<label for="labelCheck14">¿Antecedentes de fiebre reumática?</label>
			  								<div class="form-inline">
			  									<div class="radio17 form-inline">
			  									<label class="mr-1" for="op17">Si</label>		
			  									<input type="radio" id="op17" name="fiebreR">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio18 form-inline">
			  									<label class="mr-1" for="op18">No</label>	
			  									<input type="radio" id="op18" name="fiebreR">
			  								</div>
			  							</div>
			  							</div>	
			  							<div class="col-md-6">
			  								<label for="labelCheck14">¿Se protege con alguna medicación?</label>
			  								<textarea name="protegeMedicacion" class="form-control" aria-label="With textarea"></textarea>
			  							</div>	
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check14" class="d-none" onclick="deshabilitar(this.id)">		
			  								<label for="labelCheck14">¿Es diabético?</label>	
			  								<div class="form-inline">
			  									<div class="radio19 form-inline">
			  									<label class="mr-1" for="op19">Si</label>	
			  									<input type="radio" id="op19" name="diabetico">
			  									</div>
			  									<div class="radio20 form-inline">
			  									<div class="mr-2"></div>
			  									<label class="mr-1" for="op20">No</label>
			  									<input type="radio" id="op20" name="diabetico">
			  									</div>
			  								</div>			
			  							</div>
			  							<div class="col-md-3" id="diabetesControl">
			  								<label for="labelCheck14">¿Está controlado?</label>
			  							<div class="form-inline">
			  								<div class="radio21 form-inline">
			  									<label class="mr-1" for="op21">Si</label>	
			  									<input type="radio" id="op21" class="diabetesControl" name="diabControl">
			  								</div>
			  									<div class="mr-2"></div>
			  								<div class="radio22 form-inline">
			  									<label class="mr-1" for="op22">No</label>	
			  									<input type="radio" id="op22" class="diabetesControl" name="diabControl">
			  								</div>
			  								</div>	
			  							</div>
			  							<div class="col-md-6">
			  								<label for="labelCheck14" id="diabetesControl2">¿Con qué?</label>
			  								<textarea name="conQueDiabetes" class="form-control diabetesControl" aria-label="With textarea"></textarea>
			  							</div>
			  						</div>
			  						<div class="row text-left">
			  							<div class="col-md-4">
			  							<input type="checkbox" id="check15" class="d-none" onclick="deshabilitar(this.id)">
			  							<label for="labelCheck15">¿Tiene algún problema cardíaco?</label>	
			  								<div class="form-inline">
			  									<div class="radio23 form-inline">
			  										<label class="mr-1" for="op23" >Si</label>
			  										<input type="radio" id="op23" name="pCardiaco">
			  									</div>
			  									<div class=" radio24 form-inline">
			  										<label class="mr-1" for="op24">No</label>
			  										<input type="radio" id="op24" name="pCardiaco">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-4" id="pCardiaco">
			  							<label for="labelCheck15">¿Cuál?</label>
			  							<input type="text" name="cualPCardiaco" id="pCardiaco" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-5">
			  								<input type="checkbox" id="check16" class="d-none" onclick="deshabilitar(this.id)">	
			  								<label for="labelCheck16">¿Toma seguido aspirina y/o anticoagulante?</label>
			  								<div class="form-inline">
			  									<div class=" radio25 form-inline">
			  										<label class="mr-1" for="op25">Si</label>
			  										<input type="radio" id="op25" name="aspirAntic">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="radio26 form-inline">
			  										<label class="mr-1" for="op26">No</label>
			  										<input type="radio" id="op26" name="aspirAntic">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3" id="frecAspirina">
			  								<label class="labelCheck16">¿Con qué frecuencia?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio27">
			  									<label for="op27" class="mr-1">Si</label>	
			  									<input type="radio" id="op27" class="frecAspirina" name="frecAspirina">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio28">
			  									<label for="op28" class="mr-1">No</label>
			  									<input type="radio" id="op28" class="frecAspirina" name="frecAspirina">	
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check17" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck17">¿Tiene presion alta?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio29">
			  										<label for="op29" class="mr-1">Si</label>
			  										<input type="radio" id="op29" name="presionAlta">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio30">
			  										<label for="op30" class="mr-1">No</label>
			  										<input type="radio" id="op30" name="presionAlta">
			  									</div>
			  								</div>
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check18" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck17">¿Chagas?</label>
			  								<div class="form-inline ">
			  									<div class="form-inline radio31">
			  										<label for="op31" class="mr-1">Si</label>
			  										<input type="radio" id="op31" name="chagas">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio31">
			  										<label for="op32" class="mr-1">No</label>
			  										<input type="radio" id="op32" name="chagas">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3" id="chagasTrat">
			  								<label class="labelCheck17">¿Está en tratamiento?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio33">
			  										<label for="op33" class="mr-1">Si</label>
			  										<input type="radio" id="op33" class="chagasTrat" name="tratChagas">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio34">
			  										<label for="op34" class="mr-1">No</label>
			  										<input type="radio" id="op34" class="chagas" name="tratChagas">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check18" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck18">¿Tiene problemas renales?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio35">
			  										<label for="op35" class="mr-1">Si</label>
			  										<input type="radio" id="op35" name="probRenales">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio36">
			  										<label for="op36" class="mr-1">No</label>
			  										<input type="radio" id="op36" name="probRenales">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check19" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck19">¿Ulcera Gástrica?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio37">
			  										<label for="op37" class="mr-1">Si</label>
			  										<input type="radio" id="op37" name="ulceraG">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio38">
			  										<label for="op38" class="mr-1">No</label>
			  										<input type="radio" id="op38" name="ulceraG">
			  									</div>
			  									
			  								</div>
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-2">
			  								<input type="checkbox" id="check20" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck29">¿Tuvo hepatitis?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio39">
													<label for="op39" class="mr-1">Si</label>	
													<input type="radio" id="op39" name="hepatitis">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio 40">
			  										<label for="op40" class="mr-1">No</label>
			  										<input type="radio" id="op40" name="hepatitis">
			  									</div>
			  								</div>
			  							</div>
			  							<br>
			  							<div class="col-md-2 tipoHep">
			  								<label class="labelCheck20">¿De qué tipo?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio41">
			  										<label for="op41" class="mr-1">A</label>
			  										<input type="radio" id="op41" class="tipoHep" name="tipoHep">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio42">
			  										<label for="op42" class="mr-1">B</label>
			  										<input type="radio" id="op42" class="tipoHep" name="tipoHep">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio43">
			  										<label for="op43" class="mr-1">C</label>
			  										<input type="radio" id="op43" class="tipoHep" name="tipoHep">	
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-4">
			  									<input type="checkbox" id="check21" class="d-none" onclick="deshabilitar(this.id)">
			  									<label class="labelCheck21">¿Tiene algún problema hepático?</label>
			  									<div class="form-inline">
			  										<div class="form-inline radio44">
			  											<label for="op44" class="mr-1">Si</label>
			  											<input type="radio" id="op44" name="probHepatico">
			  										</div>
			  										<div class="mr-2"></div>
			  										<div class="form-inline radio45">
			  											<label for="op45">No</label>
			  											<input type="radio" id="op45" name="probHepatico">
			  										</div>
			  									</div>
			  							</div>
			  							<div class="col-md-4 cualPHep" >
			  								<label class="labelCheck21">¿Cuál?</label>
			  									<input type="text" name="cualProbHepatico" class=" cualPHep form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check22" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck22">¿Tuvo Convulsiones?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio46">
			  										<label for="op46" class="mr-1">Si</label>
			  										<input type="radio" id="op46" name="convulsiones">
			  									</div>
			  									<div class="form-inline radio 47">
			  										<label for="op47" class="mr-1">No</label>
			  										<input type="radio" id="op47" name="convulsiones">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-2">
			  								<input type="checkbox" id="check23" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck23">¿Es epiléptico?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio48 ">
			  										<label for="op48" class="mr-1">Si</label>
			  										<input type="radio" id="
			  										op48" name="epilepsia">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio49">
			  										<label for="op49" class="mr-1">No</label>
			  										<input type="radio" id="op49" name="epilepsia">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3 medEpilepsia">
			  								<label class="labelCheck23">Medicación que toma</label>
			  								<textarea name="cualProbHep" class="form-control medEpilepsia" aria-label="With textarea"></textarea>
			  							</div>
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check24" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck24">¿Ha tenido Sífilis o Gonorrea?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio48 ">
			  										<label for="op50" class="mr-1">Si</label>
			  										<input type="radio" id="
			  										op50" name="sifilis">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio51">
			  										<label for="op51" class="mr-1">No</label>
			  										<input type="radio" id="op51" name="sifilis">
			  									</div>
			  								</div>
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check24" class="d-none
			  								" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck24">¿Ha tenido Sífilis o Gonorrea?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio48 ">
			  										<label for="op52" class="mr-1">Si</label>
			  										<input type="radio" id="
			  										op52" name="sifilis">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio51">
			  										<label for="op53" class="mr-1">No</label>
			  										<input type="radio" id="op53" name="sifilis">
			  									</div>
			  								</div>
			  							</div>
			  							<br>
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check25" class="d-none" onclick="deshabilitar(this.id)">
			  								<label>¿Otra enfermedad infecto-contagiosa</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio52">
			  										<label for="op54" class="mr-1">Si</label>
			  										<input type="radio" id="54" name="enfContagiosa">	
			  									</div>
			  									<br>
			  									<div class="form-inline radio53">
			  										<label for="op54" class="mr-1">No</label>
			  										<input type="radio" id="op54" name="enfContagiosa">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check26" class=" d-none " onclick="deshabilitar(this.id)">
			  								<label class="labelCheck26">¿Tuvo transfusiones?</label>
			  									<div class="form-inline">
				  									<div class="form-inline radio53 ">
				  										<label for="op55" class="mr-1">Si</label>
				  										<input type="radio" id="
				  										op55" name="transfusiones">
				  									</div>
				  									<div class="mr-2"></div>
				  									<div class="form-inline radio56">
				  										<label for="op56" class="mr-1">No</label>
				  										<input type="radio" id="op56" name="transfusiones">
				  									</div>			  	
			  									</div>
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check27" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck27">¿Fue operado alguna vez?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio57">
			  										<label for="op57" class="mr-1">Si</label>
			  										<input type="radio" id="op57" name="operado">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio58">
			  										<label for="op58" class="mr-1">No</label>
			  										<input type="radio" id="op58" name="operado">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-4 operadoInfo">
			  								<label class="labelCheck27">¿De qué?</label>
			  								<input type="text" name="deQueOperado" class="form-control" aria-label="Default" id="operadoInfo" aria-describedby="inputGroup-sizing-default">

			  							</div>
			  							<div class="col-md-3 operadoInfo">
			  								<label class="labelCheck27">¿Cuando?</label>
			  									<input type="text" name="cuandoOperacion" class=" form-control" id="operadoInfo" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check28" class="d-none" onclick="deshabilitar(this.id)">
			  								<label>¿Tiene algún problema respiratorio?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio59">
			  										<label for="op59" class="mr-1">Si</label>
			  										<input type="radio" id="op59" name="probRespiratorio">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio60">
			  										<label for="op60" class="mr-1">No</label>
			  										<input type="radio" id="op60" name="probRespiratorio">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-3 probRespiratorio" >
			  								<label>¿Cuál?</label>
			  								<!--<input type="text" name="queProbRespiratorio" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default"> -->
			  							<input type="text" name="cualProbRespiratorio" class="form-control" id="probRespiratorio" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  							<div class="col-md-3">
			  								<input type="checkbox" id="check29" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck29">¿Fuma?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio60">
			  										<label for="op60" class="mr-1">Si</label>
			  										<input type="radio" id="op60" name="fuma">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio61">
			  										<label for="op61" class="mr-1">No</label>
			  										<input type="radio" id="op61" name="fuma">
			  									</div>
			  								</div>			  								
			  							</div>
			  						</div>	
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-5">
			  								<input type="checkbox" id="check30" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck30">¿Hay alguna otra enfermedad o recomendación de su médico que quiera dejar constancia?</label>
			  								<div class="form-inline">
			  									<div class="form-inline radio62">
			  										<label for="op62" class="mr-1">Si</label>
			  										<input type="radio" id="op62" name="recomendacionMedico">
			  									</div>
			  									<div class="mr-2"></div>
			  									<div class="form-inline radio63">
			  										<label for="op63" class="mr-1">No</label>
			  										<input type="radio" id="op63" name="recomendacionMedico">
			  									</div>
			  								</div>
			  							</div>
			  							<div class="col-md-5 recomendacion">
			  								<label class="labelCheck30">¿Cual?</label>
			  								<input type="text" name="cualRecomendacion" class="form-control" id="recomendacion" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-7">
			  								<input type="checkbox" id="check31" class="d-none" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck31">¿Realiza algún tipo de tratamiento homeopático, Acupuntura, otros?</label>
			  								<input type="text" name="acupuntura" class="form-control" aria-label="Small" aria-describedby=inputGroup-sizing-sm>
			  							</div>
			  							<div class="col-md-4">
			  								<input type="checkbox" id="check32" onclick="deshabilitar(this.id)">
			  								<label class="labelCheck32">Médico clínico</label>
			  								<input type="text" name="medicoClinico" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
				  						<div class="col-md-6">
				  							<input type="checkbox" id="check32" class="d-none" onclick="deshabilitar(this.id)">
				  							<label class="labelCheck32">¿Clínica/Hospital en caso de hacer derivación?</label>
			  								<input type="text" name="derivacion" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">		  	
			  							</div>
			  						</div>
			  						<br>
			  						<div class="row text-left">
			  							<div class="col-md-12">
			  								<input type="checkbox" class="d-none" id="check33" onclick="deshabilitar(this.id)">
			  								<label>Observación</label>
			  								<textarea name="observacion" class="form-control" aria-label="With textarea"></textarea>
			  							</div>
			  						</div>
							  	</form>	
							  	<br>
	<button type="button"  class="btn btn-lg btn-primary justify-content-l" >Guardar</button>

</body>
<script src="/sistema/jquery-3.4.1.min.js">	</script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#hcgeneral').click("input[id^=op]", function(){
			//¿sufre de alguna enfermedad?
			if ($('#op8').is(":checked")) {
				$("#pacEnf").prop("disabled", true).fadeTo(0,0.5)
				$(this).find("textarea[id=pacEnf]").prop("disabled",true).fadeTo(0,0.5)
			}else if ($('#op7').is(":checked")) {
				$("#pacEnf").prop("disabled", false).fadeTo(0,1)
				$(this).find("textarea[id=pacEnf]").prop("disabled",false).fadeTo(0,1)
			}
			//¿tiene hermanos?
			if ($('#op6').is(":checked")) {
				$("#check6").prop("disabled", true).fadeTo(0,0.5)
				$(this).find("input[id=hnoSano]").prop("disabled",true).fadeTo(0,0.5)
			}else if($ ('#op5').is(":checked")) {
				$("#check6").prop("disabled", false).fadeTo(0,1)
				$(this).find("input[id=hnoSano]").prop("disabled",false).fadeTo(0,1)				
			}
			//¿hace tratamiento medico?
			if ($('#op10').is(":checked")) {
				$("#tratMedico").prop("disabled", true).fadeTo(0,0.5)
			}else if ($('#op9').is(":checked")) {
				$("#tratMedico").prop("disabled", false).fadeTo(0,1)				
			}
			//¿Realiza algun deporte?
			if ($('#op12').is(":checked")) {
				$(".malestar").prop("disabled", true).fadeTo(0,0.5)
			}else if ($('#op11').is(":checked")) {
				$(".malestar").prop("disabled", false).fadeTo(0,1)
			}
			//¿Es diabetico?
			if ($('#op20').is(":checked")) {
				$('#diabetesControl').prop("disabled",true).fadeTo(0,0.5)
				$(this).find('.diabetesControl', 'textarea[id=diabetesControl]').prop("disabled",true).fadeTo(0,0.5)
			}else if ($('#op19').is(":checked")) {
				$('#diabetesControl').prop("disabled",false).fadeTo(0,1)
				$(this).find('.diabetesControl','textarea[id=diabetesControl]').prop("disabled",false).fadeTo(0,1)				
			}
			//¿tiene algun problema cardiaco?
			if ($('#op24').is(':checked')) {
				$("#pCardiaco").prop("disabled",true).fadeTo(0,0.5)
			}else if ($('#op23').is(':checked')) {
				$("#pCardiaco").prop("disabled",false).fadeTo(0,1)				
			}
			//¿Toma seguido aspirina y/o anticoagulante?
			if($('#op26').is(':checked')){
				$("#frecAspirina").prop("disabled",true).fadeTo(0,0.5)
				$(this).find("input[class=frecAspirina]").prop("disabled",true).fadeTo(0,0.5)
			}else if ($('#op25').is(':checked')) {
				$("#frecAspirina").prop("disabled",false).fadeTo(0,1)
				$(this).find("input[class=frecAspirina]").prop("disabled",false).fadeTo(0,1)		
			}
			//¿chagas?
			if ($('#op32').is(':checked')) {
				$("#chagasTrat").prop('disabled', true).fadeTo(0,0.5)
				$(this).find('.chagasTrat').prop('disabled',true).fadeTo(0,0.5)
			}else if ($('#op31').is(':checked')) {
				$("#chagasTrat").prop('disabled', false).fadeTo(0,1)
				$(this).find('.chagasTrat').prop('disabled',false).fadeTo(0,1)
			}
			//¿Hepatitis?
			if ($("#op40").is(":checked")) {
				$("#tipoHep").prop('disabled',true).fadeTo(0,0.5)
				$(this).find(".tipoHep").prop('disabled',true).fadeTo(0,0.5)				
			}else if ($("#op39").is(":checked")) {
				$("#tipoHep").prop('disabled',false).fadeTo(0,1)
				$(this).find(".tipoHep").prop('disabled',false).fadeTo(0,1)
			}
			//Problema hepatico
			if ($("#op45").is(":checked")) {
				$("#cualPHep").prop('disabled',true).fadeTo(0,0.5)
				$(this).find(".cualPHep").prop('disabled',true).fadeTo(0,0.5)				
			}else if ($("op44").is(":checked")) {
				$("#cualPHep").prop('disabled',false).fadeTo(0,1)
				$(this).find(".cualPHep").prop('disabled',false).fadeTo(0,1)
			}	
			//epileptico
			if ($("#op49").is(":checked")) {
				$("#medEpilepsia").prop('disabled',true).fadeTo(0,0.5)
				$(this).find(".medEpilepsia").prop('disabled',true).fadeTo(0,0.5)
			}else if ($("#48").is(":checked")) {
				$("#medEpilepsia").prop('disabled',false).fadeTo(0,1)
				$(this).find(".medEpilepsia").prop('disabled',false).fadeTo(0,1)
			}
			//¿Fue operado?
			if ($("#op58").is(":checked")) {
				$("#operadoInfo").prop('disabled',true).fadeTo(0,0.5)
				$(this).find("input[id=operadoInfo]").prop('disabled',true).fadeTo(0,0.5)
			}else if ($("#op57").is(":checked")) {
				$("#operadoInfo").prop('disabled',false).fadeTo(0,1)
				$(this).find(".operadoInfo").prop('disabled',false).fadeTo(0,1)
			}
			//problema respiratorio
			if ($("#op60").is(":checked")) {
				$("#probRespiratorio").prop('disabled',true).fadeTo(0,0.5)
				$(this).find(".probRespiratorio").prop('disabled',true).fadeTo(0,0.5)
			}else if ($("#op59").is(":checked")) {
				$("#probRespiratorio").prop('disabled',false).fadeTo(0,1)
				$(this).find(".probRespiratorio").prop('disabled',false).fadeTo(0,1)
			}
			//recomendacion
			if ($("#op63").is(":checked")) {
				$("#recomendacion").prop('disabled',true).fadeTo(0,0.5)
				$(this).find(".recomendacion").prop('disabled',true).fadeTo(0,0.5)
			}else if ($("#op62").is(":checked")) {
				$("#recomendacion").prop('disabled',false).fadeTo(0,1)
				$(this).find(".recomendacion").prop('disabled',false).fadeTo(0,1)
			}
		})
	})
</script>

</html>

<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
		case 'MODIFICAR_PACIENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar el paciente.';
			break;

		case 'MODIFICAR_PERSONA_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar modificar la persona.';
			break;
	}
}

$persona_id = $_GET['id_persona'];

$sql= "SELECT * FROM personas "
      . "INNER JOIN pacientes ON pacientes.id_persona=personas.id_persona "
      . "WHERE personas.`id_persona`=".$persona_id;

   $rs_persona = $conexion->query($sql) or die($conexion->error);


$sql=  "SELECT * FROM ocupacion";

$rs_ocupacion = mysqli_query($conexion, $sql);

$sql= "SELECT * FROM obrasocial ";
 // NO COLOCAR, ESTA SELECCIONANDO LA OBRA SOCIAL DE UN SOLO PACIENTE DEBIDO A $persona_id = $_GET['id_persona'];
 //."INNER JOIN pacientes on pacientes.`id_obrasocial`= obrasocial.`id_obrasocial` "
 //."WHERE pacientes.id_persona =". $persona_id;

$rs_obrasocial= mysqli_query($conexion,$sql);


$persona = $rs_persona->fetch_assoc();

if (!$persona) {
	header("location: listado.php?mensaje=NO_EXISTE_PERSONA");
	exit;
}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Pacientes</title>
</head>
<body>
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Modificar paciente</b></h1>
    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>
		<form method="POST" action="procesamiento/procesarEditar.php">
			<input type="hidden" name="persona_ID" value="<?php echo $persona['id_persona']; ?>">
			<table border="1" cellpadding="2" cellspacing="0">
				<tbody>
					<tr>
						<td>Nombre </td>
						<td>
							<input
							  type="text"
							  name="nombre"
							  value="<?php echo utf8_encode($persona['nombre']); ?>">
						</td>
					</tr>
					<tr>
						<td>Apellido </td>
						<td>
							<input
							  type="text"
							  name="apellido"
							  value="<?php echo utf8_encode($persona['apellido']); ?>">
						</td>
					</tr>
					<tr>
						<td>DNI: </td>
						<td>
							<input
							  type="text"
							  name="DNI"
							  value="<?php echo $persona['DNI']; ?>">
					    </td>
					</tr>
					<tr>
						<td>Fecha de nacimiento </td>
						<td>
							<input
							  type="date"
							  name="fechaNaci"
							  value="<?php echo $persona['fechanacimiento']; ?>">
					    </td>
				    <tr>
						<td>Fecha de ingreso </td>
						<td>
							<input
							  type="date"
							  name="fechaIn"
							  value="<?php echo $persona['fechaingreso']; ?>">
					    </td>
					</tr> 
					     <tr>
                             <td>Ocupacion</td>
                               <td>
                                 <select name="cboOcupacion">
                                   <?php while ($row = $rs_ocupacion->fetch_assoc()): ?>

                                    <?php
                                     if ($persona['id_ocupacion'] == $row['id_ocupacion']):
                                        $selected = 'SELECTED';
                                         else:
                                         $selected = '';
                                         endif;
                                          ?>
 
                                        <option value="<?php echo $row['id_ocupacion']; ?>" <?php echo $selected; ?>>
                                   <?php echo $row["descripcion"]; ?>
                                </option>
                                  <?php endwhile; ?>
                                </select>
                           </td>
                      </tr>	

                      <tr>
                             <td>Obra social</td>
                               <td>
                                 <select name="cboObrasocial">
                                   <?php while ($row = $rs_obrasocial->fetch_assoc()): ?>

                                    <?php
                                     if ($persona['id_obrasocial'] == $row['id_obrasocial']):
                                        $selected = 'SELECTED';
                                         else:
                                         $selected = '';
                                         endif;
                                          ?>
 
                                        <option value="<?php echo $row['id_obrasocial']; ?>" <?php echo $selected; ?>>
                                   <?php echo $row["descripcion"]; ?>
                                </option>
                                  <?php endwhile; ?>
                                </select>
                           </td>
                      </tr>	

				    <tr>
				    	<td colspan="2">
				    		<input type="submit" value="Guardar">
				    	</td>
				    </tr>
				</tbody>
			</table>
		</form>
	</div>
</body>
</html>
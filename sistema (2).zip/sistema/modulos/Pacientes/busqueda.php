<?php
require '../../php/conexion.php';

$tabla="";
$query="SELECT pacientes.`id_paciente`,fechaingreso, personas. id_persona,`nombre`, apellido, DNI, fechanacimiento, obrasocial.`descripcion`AS 'obra social', pac_estado. estado AS 'estado de paciente'
 FROM pacientes ".
"INNER JOIN personas ON pacientes.`id_persona`= personas.`id_persona` ".
"INNER JOIN obrasocial ON pacientes.`id_obrasocial`=obrasocial.`id_obrasocial` ".
"INNER JOIN pac_estado ON pacientes.`id_pac_estado`=pac_estado.`id_pac_estado`".
 "WHERE pac_estado.estado= 'Activo' ";


 if (isset($_POST['busqueda'])) {
 	$q=$conexion->real_escape_string($_POST['busqueda']);
 	$query="SELECT*FROM pacientes ".
		"WHERE nombre LIKE '%".$q."%' OR 
		apellido LIKE '%". $q. "%'";
 }

$buscarPacientes=$conexion->query($query);

if ( !empty($buscarPacientes) && $buscarPacientes->num_rows > 0) {
	$tabla.=
	 '<thead class="cabeza">
	    <tr>
		  	<th>Apellido</th>    	
		 	<th>Nombre</th>
		 	<th>DNI</th>
		 	<th>Fecha de nacimiento</th>
			<th>Fecha Ingreso</th>
			<th>Obra social</th>
			<th>Estado</th>
			<th>Acciones</th>
	    </tr>
	  </thead>';

	  while ($filaPacientes=$buscarPacientes->fetch_assoc()){	
	    $tabla.=
	  	'<tr>
	  		<td>'.$filaPacientes['nombre'].'</td>
	  		<td>'. $filaPacientes['apellido'].'</td>
	  		<td>'. $filaPacientes['DNI'].'</td>	  		
	  		<td>'.$filaPacientes['fechanacimiento'].'</td>	  	
	  		<td>'.$filaPacientes['fechaingreso'].'</td>
	  		<td>'.$filaPacientes['fechanacimiento'].'</td>
	  		<td>'.$filaPacientes['obra social'].'</td>
	  		<td> <span class="badge badge-pill badge-success">'
	  		.($filaPacientes['estado de paciente']).
	  		'</span> </td>
	  		<td> <span  class="badge badge-pill badge-danger pointer" data-toggle="modal" data-target="#baja"> Dar de baja </span>|<span class="badge badge-pill badge-primary"><a href="perfil.php?id_persona='.$filaPacientes['id_persona'].'" style="color:white">Ver más</a> </span> </td>';
			$tabla.='</table>';
	} 
}else{
	$tabla="No se encontraron coincidencias con sus criterios de búsqueda";
}



?>
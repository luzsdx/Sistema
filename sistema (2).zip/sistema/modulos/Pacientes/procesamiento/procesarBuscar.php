<?php


require('../../../php/conexion.php');

if(isset($_POST["filtro"]) and !empty($_POST['filtro'])){
	$filtro = trim($_POST["filtro"]);
} else {
	echo "<h1><b>Resultado de búsqueda</b></h1><br>";
	echo "<a href='listado.php'>Lista de Pacientes</a> &nbsp;||&nbsp;";
	echo "<a href='altaPaciente.php'>Agregar</a> &nbsp;||&nbsp;";
	echo "<a href='buscar.php'>Buscar</a> &nbsp;||&nbsp;";
	echo "<a href='dashboard.php'>Volver</a><br><br>";
	echo "<p>Por favor ingrese un parámetro de búsqueda.</p>";
	
	return false;
}


$sql = "SELECT personas.id_persona, nombre,apellido,DNI, fechanacimiento, pacientes. id_paciente,fechaingreso, nro_afiliado, ocupacion. id_ocupacion AS 'ocupacion', obrasocial. id_obrasocial AS 'obrasocial'"
	. " FROM pacientes"
	. " INNER JOIN personas ON pacientes.id_persona = personas.id_persona "
	. " INNER JOIN ocupacion ON pacientes.id_ocupacion= ocupacion. id_ocupacion"
	. " INNER JOIN obrasocial ON pacientes.id_obrasocial= obrasocial. id_obrasocial"
	. " WHERE nombre LIKE '%$filtro%' OR apellido LIKE '%$filtro%' ORDER BY nombre ASC";


$rs = mysqli_query($conexion,$sql);


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Resultado</title>
	<link rel="stylesheet" href="">
</head>
<body>
 <div align='center'>
	<h1><b>Resultado de búsqueda</b></h1>
	<p>
		<a href="../listado.php">Lista de pacientes</a> || 
		<a href="../altaPaciente.php">Agregar</a> || 
		<a href="../buscar.php">Buscar</a>
	</p>
	<br>
	<table border="1" cellpadding="2" cellspacing="0">
		<thead>
				<tr>
					<th>ID</th>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>DNI</th>
					<th>Fecha de nacimiento</th>
					<th>Fecha Ingreso</th>
					<th>Nro de afiliado</th>
					<th>Ocupación</th>
					<th>Obra social</th>
					<th>Contacto</th>
					<th>Domicilio</th>
					<th>Acciones</th>
				</tr>
		</thead>
		<tbody>
			
			<?php while($row = $rs->fetch_assoc()):?>
					
					    <td> <?php echo utf8_encode($row['id_paciente']); ?> </td>
						<td> <?php echo utf8_encode($row['nombre']); ?> </td>
						<td> <?php echo utf8_encode($row['apellido']); ?> </td>
						<td> <?php echo utf8_encode($row['DNI']); ?> </td>
						<td> <?php echo utf8_encode($row['fechanacimiento']); ?> </td>
						<td> <?php echo utf8_encode($row['fechaingreso']); ?> </td>		
						<td> <?php echo utf8_encode($row['nro_afiliado']); ?> </td>
						<td> <?php echo utf8_encode($row['ocupacion']); ?> </td>
						<td> <?php echo utf8_encode($row['obrasocial']); ?> </td>
						<td><a href="../../contacto/listado.php?id_persona=<?php echo $row['id_persona'];?>">Ver</a> </td>
						<td><a href="../../domicilio/listado.php?id_persona=<?php echo $row['id_persona']; ?>">Ver</a></td>

						<td><a href="../editar.php?id_paciente=<?php echo $row['id_persona']; ?>">
							    Editar
							</a> | 
							<a href="procesamiento/procesarBaja.php?id_persona=<?php echo $row['id_persona']; ?>" onclick="return confirm('¿Estas seguro de que deseas eliminar el paciente?' )">
							    Eliminar
							</a>
						</td>
					</tr>
			<?php endwhile; ?>
		</tbody>		

	</table>
 </div>
</body>
</html>

<?php

// CERRAMOS LA CONEXION A LA DB
mysqli_close($conexion);

?>
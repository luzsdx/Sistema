<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location:../../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$table1= 'obrasocial';
$table2='ocupacion';

$persona_id= $_POST["persona_ID"];
$nombre= $_POST["nombre"];
$apellido= $_POST["apellido"];
$dni= $_POST["DNI"];
$fechanacimiento= $_POST["fechaNaci"];
$fechaingreso= $_POST["fechaIn"];
$ocupacion= $_POST["cboOcupacion"];
$obrasocial= $_POST["cboObrasocial"];
$estado= "Activo";

// MODIFICO PERSONA
$sql = "UPDATE personas "
     ."SET nombre = '$nombre', apellido = '$apellido', "
     . "DNI = '$dni', fechanacimiento = '$fechanacimiento', estado = '$estado' "
     . "WHERE personas.id_persona = " . $persona_id;


// si no puedo modificar, redirecciono al formulario con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'MODIFICAR_PERSONA_ERROR';
	header("location: ../editar.php?id_persona=$persona_id&mensaje=$mensaje");
	exit;
}

// MODIFICO PACIENTE
$sql = "UPDATE pacientes SET id_ocupacion = '$ocupacion', id_obrasocial='$obrasocial', fechaingreso='$fechaingreso' "
     . "WHERE id_persona = " . $persona_id;


// si no puedo guardar, redirecciono al listado con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'MODIFICAR_PACIENTE_ERROR';
	header("location: ../editar.php?id_persona=$persona_id&mensaje=$mensaje");
	exit;
}

$mensaje = 'MODIFICAR_PACIENTE_OK';
header("location: ../listado.php?mensaje=$mensaje");

?>
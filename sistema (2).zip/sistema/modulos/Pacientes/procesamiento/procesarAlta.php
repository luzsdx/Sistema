<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location: ../../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$dni=$_POST['dni'];
$nacimiento= date($_POST['nacimiento']);
$embarazoSi=$_POST['embarazoSi'];
$embarazoNo=$_POST['embarazoNo'];
$mesesEmb=$_POST['mesesEmb'];
$obraSocial=$_POST['obraSocial'];
$afiliado=$_POST['afiliado'];
$observacion=$_POST['observacion'];
$celular=$_POST['celular'];
$fijo=$_POST['fijo'];
$correo=$_POST['correo'];
$provincia=$_POST['provincia'];
$ciudad=$_POST['ciudad'];
$barrio=$_POST['barrio'];
$calle=$_POST['calle'];
$altura=$_POST['altura'];
$piso=$_POST['piso'];
$manzana=$_POST['manzana'];
$sector=$_POST['sector'];
$observacionDom=$_POST['observacionDom'];
$generoM=$_POST['generoM'];
$generoF=$_POST['generoF'];

$id_persona= $_GET["id_persona"];
$id_genero= $_GET["id_genero"];
$id_domicilio= $_GET["id_domicilio"];
$id_ciudad= $_GET["id_ciudad"];
$id_embarazo=$_GET["id_embarazo"];
$id_ocupacion=$_GET["id_ocupacion"];
$id_obrasocial=$_GET["id_obrasocial"];


$sql_personas="INSERT INTO personas ('nombre','apellido','DNI',fechanacimiento)".
"VALUES ('$nombre','$apellido','$dni', $nacimiento)";

mysqli_query($conexion,$sql_personas);

$sql_pacientes

?>
<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
        case 'GUARDAR_PACIENTE_OK':
            $mensaje = 'Paciente agregado correctamente.';
            break;

		case 'GUARDAR_PACIENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear el Paciente.';
			break;

		case 'GUARDAR_PERSONA_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear la persona.';
			break;
	}
}



$sql = "SELECT pacientes.`id_paciente`,fechaingreso, personas. id_persona,`nombre`, apellido, DNI, fechanacimiento, 
 obrasocial.`descripcion`AS 'obra social', pac_estado. estado AS 'estado de paciente'
 FROM pacientes ".
"INNER JOIN personas ON pacientes.`id_persona`= personas.`id_persona` ".
"INNER JOIN obrasocial ON pacientes.`id_obrasocial`=obrasocial.`id_obrasocial` ".
"INNER JOIN pac_estado ON pacientes.`id_pac_estado`=pac_estado.`id_pac_estado`".
 "WHERE pac_estado.estado= 'Activo'";
$rs = mysqli_query($conexion,$sql);

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
    <link rel="stylesheet" type="text/css" href="/sistema/bootstrap-4.4.1-dist/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css">
	<link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">


	<style type="text/css" media="screen">
		.pointer{
			cursor:pointer;
		}
	</style>
</head>
<body>
	<?php require '../../php/menu.php'; ?>
	<br>
    	      <?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>
<div class="container">
  <div class="card shadow">
    <div class="card-header " > <b> Lista de Pacientes </b> </div>
    <div class="card-body">
    	<div class="card">
 		  <div class="card-body">
 		  	<div class="row text-left">
				<div class="col-sm-2">
					Desde:
					<br>
 		  			<input type="date" name="fecha"class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">	
				</div>
				<div class="col-sm-2"> 
					Hasta:
					<br>
 		  			<input type="date" name="fecha"class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
				</div>
				<div class="col-sm-8">
					Buscar Paciente
					<br>
						<div class="input-group mb-3">
 						 <input type="search" name="buscador" class="form-control" id="busqueda" aria-describedby="basic-addon2">
 						 <div class="input-group-append">
					  </div>
					</div>
 		  		</div>
 			 </div>
		</div>
	</div>	
    	<br>

    	<div class="float-left">
    		<a href="alta.php?id_persona= " class="btn btn-success">Añadir Paciente</a>    		
    		<a href="bajas.php" class="btn btn-danger">Pacientes dados de baja</a>
    	</div>

    	<!--En caso de que no haya resultados de la búsqueda
    	-->	
    	<section id="tabla_resultados">
    		
    	</section>
   		 <!-- -->


    	<div class="table-responsive">

 <table id="listadoPacientes" class="table table-hover table-borderless ">
    		<br>
  <thead class="cabeza">
    <tr>
	  	<th>Apellido</th>    	
	 	<th>Nombre</th>
	 	<th>DNI</th>
	 	<th>Fecha de nacimiento</th>
		<th>Fecha Ingreso</th>
		<th>Obra social</th>
		<th>Estado</th>
		<th>Acciones</th>
    </tr>
  </thead>
  <tbody>
  	<!-- fetch_assoc recupera una fila de resultados como un array asociativo -->
<?php while ($row = $rs->fetch_assoc()): ?>
	<tr>
		<td> <?php echo utf8_encode($row['apellido']); ?> </td>
		<td> <?php echo utf8_encode($row['nombre']); ?> </td>		
		<td> <?php echo utf8_encode($row['DNI']); ?> </td>
		<td> <?php echo utf8_encode($row['fechanacimiento']); ?> </td>
		<td> <?php echo utf8_encode($row['fechaingreso']); ?> </td>				
		<td> <?php echo utf8_encode($row['obra social']); ?> </td>
		<td> <span class="badge badge-pill badge-success"><?php echo utf8_encode ($row['estado de paciente']); ?></span> </td>

		<td> <span class="badge badge-pill badge-danger pointer" data-toggle="modal" data-target="#baja" data-id=".'$row['id_persona']'. " >Dar de baja</span>|

			<span class="badge badge-pill badge-primary"><a href="perfil.php?id_persona=<?php echo $row['id_persona'];?>" style="color:white">Ver más</a> </span> </td>
	</tr>
	<?php endwhile; ?>
  </tbody>
</table>
<br>
</div>
<nav aria-label="Page navigation">
					<ul class="pagination">
				    <li>
				      <a href="index.php?page=<?= $Previous; ?>" aria-label="Previous">
				        <span aria-hidden="true">&laquo; Previous</span>
				      </a>
				    </li>
				    	<li class="page-item"><a class="page-link" href="index.php?page=<?= $i; ?>"><?= $i; ?></a></li>
				      <a href="index.php?page=<?= $Next; ?>" aria-label="Next">
				        <span aria-hidden="true">Next &raquo;</span>
				      </a>
				    </li>
				  </ul>
				</nav>
     </div>
   </div>
</div>



<div class="modal fade" id="baja" tabindex="-1" role="dialog" aria-labelledby="baja" aria-hidden="true">
 <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bajaLabel">Dar de baja Paciente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<!--<?// while ($row= $rs->fetch_assoc()): ?> -->
      	¿Está seguro de dar de baja el paciente <?php echo $row['id_persona'];?> ?
      	<!--<? //endwhile; ?> -->
      	?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <button type="button" onclick="dar_baja(<?php $row['id_persona'] ?>)" class="btn btn-primary">Aceptar</button>
      </div>
    </div>
  </div>

</div>
</body>
<script src="/sistema/bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script> 

<script src="/sistema/jquery-3.4.1.min.js">

//forma abreviada de document ready
$(obtener_registros());

	function obtener_registros(){
		$.ajax({
			url: 'busqueda.php',
			type: 'POST',
			dataType: 'JSON',
			data: {
				"buscador":$('buscador').val().trim();			
			}, 
			success: function(respuesta){
					if (respuesta== '200') {
						$('#tabla_resultado').html();
					}else{
						alert('Error en la busqueda')
					}
				}

			})
		}

//			success:(function(){
//			$("#tabla_resultado").html();
//				})

//procesar los resultados del input
//$().on('keyup','#busqueda',function(){
	//obtener el valor escrito dentro de #busqueda
//	var valorBusqueda=$(this).val();
	//si valorBusqueda contiene valores entonces
//	if (valorBusqueda!=""){
		//a la funcion obtener registros se le da como parametro la variable valorBusqueda
//		obtener_registros(valorBusqueda);
//	}else{
//		obtener_registros();
//	}
// })
</script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
<script type="text/javascript">
	$(document).ready( function () {
    $('#listadoPacientes').DataTable(){
    	paging: true

    }
} );
</script>

</html>
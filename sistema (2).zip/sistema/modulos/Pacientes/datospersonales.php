<?php


$sql="SELECT*FROM embarazo";
$rs_embarazo=mysqli_query($conexion,$sql);

$sql="SELECT*FROM obrasocial";
$rs_obrasocial=mysqli_query($conexion,$sql);

$sql= "SELECT * FROM provincia ";
$rs_provincia=mysqli_query($conexion,$sql);

$sql="SELECT * FROM ciudades";
$rs_ciudad=mysqli_query($conexion,$sql);

$sql="SELECT estado 
FROM pac_estado".
"WHERE id_pac_estado=1 ";


$id_persona= $_GET["id_persona"];



?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Agregar Paciente</title>
	<script type="text/javascript" src="../../funciones/consultarCombos.js"></script>
	<link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
	<link rel="stylesheet" type="text/css" href="/sistema/bootstrap-4.4.1-dist/css/bootstrap.min.css">


</head>
<body>
							<form id="datosPersonales" method="POST" action="#" accept-charset="utf-8">
								<input type="hidden"  value="<?php echo $id_persona;?>" name="id_persona">
								<input type="hidden"  value="<?php echo $id_genero;?>" name="id_genero">
								<input type="hidden"  value="<?php echo $id_domicilio;?>" id="id_domicilio">
								<input type="hidden"  value="<?php echo $id_ciudad;?>" name="id_ciudad">
								<input type="hidden"  value="<?php echo $id_embarazo;?>" name="id_embarazo">
								<input type="hidden"  value="<?php echo $id_ocupacion;?>" name="id_ocupacion">
								<input type="hidden"  value="<?php echo $id_obrasocial;?>" name="id_obrasocial">

						      	<div class="row text-left">
			 				 		<div class="col-md-6">
			 				 			Nombre
			  				 		  <input type="text" id="nombre" name="nombre" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			 				 		</div>
			 				 		<div class="col-md-6">
			 				 			Apellido 		
			 			 		  <input type="text" id="apellido" name="apellido" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			 				 		</div> 				 		
			 				 	</div>
			 				 	<br>
			 				 	<div class="row text-left">
			 				 		<div class="col-md-2">
			 				 			D.N.I				 		
			 				 			<input type="text" id="dni" name="dni"class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			 				 		</div>
			  				 		<div class="col-md-5">
			 				 			Fecha de nacimiento
			 				 			<input type="date" id="nacimiento" name="nacimiento"class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			 				 		</div>
			 				 		<div class="col-md-5">
			 				 			Fecha de ingreso
			 				 			<input type="date" id="ingreso" name="ingreso"class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">
			 				 		</div>				 		
			 				 	</div>
			 				 	<br>
			 				 	<div class="row text-align">
			 				 		<div class="col-md-4">
			 				 			Género
			 				 			<div class="text-align">
			 				 			<input type="radio" name="genero" id="generoM">Masculino
			 				 			<input type="radio" name="genero" id="generoF">Femenino
			 				 		</div>	 				 		
			 				 			</div>
			 				 		<div class="col-md-4" id="pregDiv">
			 				 			<label class="embarazo">¿Está embarazada?</label>
			 				 			<div class="form-inline">
			 				 				<div class="form-inline">
			 				 					<label class="mr-1" for="embarazoRadio">Si</label>
			 				 					<input type="radio" id="embarazoRadio" name="embarazada">
			 				 				</div>
			 				 				<div class="mr-2"></div>
			 				 				<div class="form-inline">
			 				 					<label class="mr-1" for="embarazoRadio">No</label>
			 				 					<input type="radio" id="embarazoRadio" name="embarazada">
			 				 				</div>
			 				 		</div>
			 				 		</div>
			 				 		<div class="col-md-4" id="pregMDiv">
			 				 			<label class="embarazo">¿De cuántos meses?</label>
			 				 			<select name="embarazoSelect" id="mesesSelect" class="custom-select">
			 				 			<option class="embarazo" value="sinEspecificar">Sin especificar</option>	
			 				 			<?php while ($row=$rs_embarazo->fetch_assoc()): ?>
			 				 				 <option id="mesesEmb"> value="<?php echo $row['id_embarazo']; ?>">
								                <?php echo $row["meses"]; ?>
								                </option>
								        <?php endwhile; ?>
								   		 </select>
			 				 		</div>
			 				 		</div>
			 				 	</div>
			 				 	<br>
			 				 	<div class="row text-left">
			 				 		<div class="col-md-4">
			 				 			Ocupación 				
			 				 		<input type="text" id="ocupacion" name="ocupacion"class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm">	
			 				 		</div>
			  				 		<div class="col-md-4" id="divObraSocial">
			 				 			Obra social 
			 				 			<select name="obraSocial" id="obraSocial" class="custom-select">
			 				 			<option value="">Sin especificar</option>
			 				 			<?php while ($row=$rs_obrasocial->fetch_assoc()): ?>
			 				 				 <option value="<?php echo $row['id_obrasocial']; ?>">
								                <?php echo $row["descripcion"]; ?>
								             </option>
								        <?php endwhile; ?>
								   		 </select>
			 				 		</div>
			 				 		<div id="div_afiliado" class="col-md-4">
			 				 			<label id="Afiliado">N° Afiliado </label>
			 				 			<input id="afiliado" type="text" name="afiliado" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			 				 		</div> 				 						 		
			 				 	</div>
			 				 	<br>
			 				 		<div class="row text-align">
			 				 			<div class="col-md-12">
			 				 			Observación
			 				 	 		 <textarea id="observacion" class="form-control" aria-label="With textarea"></textarea>	
			 				 			</div>
			 						 </div> 				 	
			 				 	<br>
			 				 	<hr>
			 				 	<strong>Datos de contacto</strong>
			 				 	<div class="row text-left">
			 				 		<div class="col-md-4">
			 				 			Celular
										<input type="text" id="celular" name="celular" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default"> 				 			
			 				 		</div>
			 				 		<div class="col-md-4">
			 				 			Teléfono fijo
			 				 			<input type="text" id="fijo" name="fijo" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			 				 		</div>
			 				 		<div class="col-md-4">
			 				 			Correo electrónico
			 				 			<input type="email" id="correo" name="correo" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">
			 				 		</div> 				 		
			 				 	</div>
			 				 	<br>
			 				 	<hr>
			 				 	<strong>Datos de domicilio</strong>
			 				 	<div class="row text-left">
			 				 		<div class="col-md-6">
			 				 			Provincia
			 				 			 <select class="custom-select" name="cboProvincia"  id="inputGroupSelect02"
											         onchange="consultarCiudades(this.value)">
											          <option value="" >Sin especificar</option>
													    <?php while ($datosProvincia=mysqli_fetch_array($rs_provincia)){ ?>
											            <option id="provincia"> value= "<?php echo $datosProvincia['id_provincia'] ?>"> <?php echo $datosProvincia['descripcion']; ?> </option>
											          <?php } ?> 
			  							</select>
			 				 		</div>
			 				 		<div class="col-md-6">
			 				 			Ciudad
			 				 			 <select class="custom-select" name="cboCiudad"  id="inputGroupSelect02" onchange="consultarCiudades(this.value)">
											<option value="" >Sin especificar</option>
											<?php while ($datosCiudad=mysqli_fetch_array($rs_ciudad)){ ?>
											<option id="ciudad"> value= "<?php echo $datosCiudad['id_ciudad'] ?>"> <?php echo $datosCiudad['descripcion']; ?> </option>
											 <?php } ?> 
			  							</select>
			  							</select>
			 				 		</div> 				 		
			 				 	</div>
			 				 	<br>
			 				 <div class="row text-left">
			 				 	<div class=" col-md-4">
			 				 	Barrio:
			 				  	<select class="custom-select" id="barrio">
			 					<option selected>Choose...</option>
			  					<option value="1">One</option>
			   					<option value="2">Two</option>
			   					<option value="3">Three</option>
			  					</select>
			  					</div>	
			 				 <div class=" col-md-4">
			 				 	Calle:
			 				  	<select class="custom-select" id="calle">
			 					<option selected>Choose...</option>
			  					<option value="1">One</option>
			   					<option value="2">Two</option>
			   					<option value="3">Three</option>
			  					</select>	
			 				 </div>
			 				 <div class="col-md-4">
			 				 	Altura:
			 				 	<input id="altura" type="text" name="altura" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default"> 				 		
			 				 </div>
			 				 </div>
			 				 <br>
			 				 <div class="row text-align">
			 				 	<div class="col-md-3">
			 				 		Piso:
			 				 	<input id="piso" type="text" name="piso" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">				 		
			 				 	</div>
			 				 	<div class="col-md-3">
			 				 		Torre:
							 	<input id="torre" type="text" name="piso" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">	 				 		
			 				 	</div>
			 				 	<div class="col-md-3">
			 				 		Manzana:
							 	<input id="manzana" type="text" name="manzana" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">	 				 		
			 				 	</div>
			 				 	<div class="col-md-3">
			 				 		Sector/Parcela:
							 	<input id="sector" type="text" name="sectorp" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default">	 				 		
			 				 	</div> 				 	 				 	
			 				 </div>
			 				 <br>
			 				 <div class="row text-align">
			 				 	<div class="col-md-12">
			 				 		Observación:
			 				 	  <textarea id="observacionDom" class="form-control" aria-label="With textarea"></textarea>	
			 				 	</div>
			 				 </div>
			 				 <br>
			 				 <div class="text-right">
							 <button type="submit" class="btn btn-lg btn-primary" >Guardar</button>
							 	
			 				  </div>	 
			 				</div>
			      		  </form>
</body>
<script src="/sistema/jquery-3.4.1.min.js">
</script>
<script type="text/javascript" src="/sistema/js/jquery.validate.js"></script>
<script type="text/javascript" src="valDpersonales.js"></script>
<script src="/sistema/bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script>
<script type="text/javascript">


	$(document).ready(function(){
		//si la persona es hombre, los campos de embarazo se deshabilitan
	$("#datosPersonales").click("input[id^=genero]", function(){
		if ($("#generoM").is(":checked")) {
			//deshabilitar el div de select
			$("div[id=pregDiv]").prop("disabled", true).fadeTo(0,0.5)
			$(this).find("input[id='embarazoRadio']").prop("disabled", true)
			//deshabilita la opcion de seleccionar
			$("div[id=pregMDiv]").prop("disabled", true).fadeTo(0,0.5)	
			$(this).find('#mesesSelect').prop("disabled", true)

		}else if($("#generoF").is(":checked")){
			$("div[id=pregDiv]").prop("disabled", false).fadeTo(0,1)	
			$(this).find("input[id='embarazoRadio']").prop("disabled", false)

			$("div[id=pregMDiv]").prop("disabled", false).fadeTo(0,1)
			$(this).find('#mesesSelect').prop("disabled", false)				

		}
	})
	//si es mujer y no esta embarazada el campo de meses se deshabilita
	$('div[id=pregDiv]').click("input[id$=Emb]", function(){
		if ($("#noEmb").is(":checked")) {
			$('div[id=pregMDiv]').prop('disabled', true).fadeTo(0,0.5)
		}else if ($("#siEmb").is(":checked")) {
			$('div[id=pregMDiv]').prop('disabled', false).fadeTo(0,1)
		}
	})

	//si selecciona "sin especificar" de la obra social, entonces el campo de nro afiliado se deshabilita

	//if ($('select[id=obraSocial], option:selected').not(' option[value=sinEspecificar]')) {
	//	$('#div_afiliado').prop('disable', true).fadeTo(0,0.5)
	//}
	//validar
$.ajax({
	url: "altaDatosP.php",
	type: "POST",
	dataType:"JSON",
	data: {
		'nombre' :  $('#nombre').val().trim(),
		'apellido':$('#apellido').val().trim(),
		'dni':$('#dni').val().trim(),
		'nacimiento':$('#nacimiento').val().trim(),
		'embarazoSi':$('#embarazoSi').val().trim(),
		'embarazoNo':$('#embarazoNo').val().trim(),
		'mesesEmb':$('#obraSocial').val().trim(),
		'obraSocial':$('#obraSocial').val().trim(),
		'afiliado':$('#afiliado').val().trim(),
		'observacion':$('#observacion').val(),
		'celular':$('#celular').val().trim(),
		'fijo':$('#fijo').val().trim(),
		'correo':$('#correo').val().trim(),
		'provincia':$('#provincia').val().trim(),
		'ciudad':$('#ciudad').val().trim(),
		'barrio':$('#barrio').val().trim(),
		'calle':$('#calle').val().trim(),
		'altura':$('#altura').val().trim(),
		'piso':$('#piso').val().trim(),
		'manzana':$('#manzana').val().trim(),
		'sector':$('#sector').val().trim(),
		'observacionDom':$('#observacionDom').val().trim(),
		'generoM':$('#generoM').val().trim(),
		'generoF':$('#generoF').val().trim(),

	},

})

})		
</script>
<script src="/sistema/bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script> 

</html>
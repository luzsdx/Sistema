<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location: ../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}


$id_persona= $_POST['ID'];
$tipocontacto=$_POST["cboTipocon"];
$contacto= $_POST['descripcionc'];
// cuando agrego nuevo contacto estado = 1
$estado = 1;

switch ($_POST["cboTipocon"]) {
	case '0':
		$id_tipocontacto=4	;
		break;
	case '1':
		$id_tipocontacto=2;
		break;
	case '2':
		$id_tipocontacto=3;
		break;

	case '3':
		$id_tipocontacto=1;
		break;
}





// GUARDO 	CONTACTO
$sql = "INSERT INTO persona_contacto (`id_persona`,`id_tipocontacto`,`valor`,  `estado`) "
 ." VALUES($id_persona, $tipocontacto, '$contacto',$estado)";





// si no puedo guardar, redirecciono al formulario con mensaje de error
//NO N O COLOCAR, SE ESTÁ EJECUTANDO 2 VECES $rs = $conexion->query($sql) or die ($conexion->error) ;


if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'GUARDAR_CONTACTO_ERROR';
	header("location: ../listado.php?id_persona=$id_persona&mensaje=$mensaje");
	exit;
}

$mensaje = 'GUARDAR_CONTACTO_OK';
header("location: ../listado.php?id_persona=$id_persona&mensaje=$mensaje");

?>
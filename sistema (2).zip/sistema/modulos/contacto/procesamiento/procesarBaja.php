<?php

require ('../../../php/conexion.php');

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location:../../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$persona_id = $_GET['id_persona'];
$domicilio_id=$_GET['id_contacto'];

// MODIFICO PERSONA
$sql = "UPDATE persona_contacto SET estado = 0 WHERE id_persona_contacto= " . $domicilio_id;

// si no puedo modificar, redirecciono al formulario con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'PERSONA_ESTADO_UPDATE_ERROR';
	header("location: ../listado.php?id_persona=$persona_id&mensaje=$mensaje");
	exit;
}

$mensaje = 'PERSONA_ESTADO_UPDATE_OK';
header("location: ../listado.php?id_persona=$persona_id&mensaje=$mensaje");

?>
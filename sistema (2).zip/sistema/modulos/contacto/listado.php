<?php

require '../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
        case 'GUARDAR_CONTACTO_OK':
            $mensaje = 'Contacto agregado correctamente.';
            break;

		case 'GUARDAR_CONTACTO_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear el contacto.';
			break;
	}
}


$id_persona= $_GET['id_persona'];
/*if($id_persona==""){
echo "dato vacio";
}else{
  echo $id_persona;
}
exit(); */ 
$sql= "SELECT nombre, apellido FROM personas where id_persona = $id_persona";

$rs_na=mysqli_query($conexion,$sql);

$persona = mysqli_fetch_array($rs_na);

$nombre = $persona['nombre']." ".$persona['apellido'];




$sql="SELECT  persona_contacto.`valor`, tipocontacto.`descripcion` AS 'tipocontacto', persona_contacto. id_persona_contacto "
     ."FROM persona_contacto "
     ."INNER JOIN personas ON persona_contacto.`id_persona`= personas.`id_persona` "
     ."INNER JOIN tipocontacto ON persona_contacto.`id_tipocontacto`=tipocontacto.`id_tipocontacto` "
     ."WHERE persona_contacto.estado=1 AND personas.id_persona=".$id_persona;

$rs = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html>
<head>
	<title>Contactos</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Contactos</b></h1>

    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>

            <!--<?php //$id_persona= $_GET['id_persona']; ?>-->
		<p><a href="alta.php?id_persona=<?php echo $id_persona= $_GET['id_persona'];?>">Nuevo contacto</a></p>
		<br>

			<p><h2><?php  echo utf8_encode($nombre); ?></h2></p>

		<table border="1" cellpadding="2" cellspacing="0">
			<thead>
				<tr>
					<th>ID</th>
					<th>Tipo contacto</th>
					<th>Contacto</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody> 
				<?php while ($row = $rs->fetch_assoc()): ?>
					<tr>
						<td> <?php echo utf8_encode($row['id_persona_contacto']); ?> </td>
						<td> <?php echo utf8_encode($row['tipocontacto']); ?> </td>
						<td> <?php echo utf8_encode($row['valor']); ?> </td>

						<td>
                    <a href="procesamiento/procesarBaja.php?id_persona=<?php echo $id_persona; ?> &id_contacto=<?php echo $row['id_persona_contacto']; ?>" onclick="return confirm('¿Estas seguro de que deseas eliminar el paciente?' )">Eliminar
							</a>
						</td>
					</tr>
				<!--<?php// break; ?>	-->
				<?php endwhile; ?>
			</tbody>
		</table>
	</div>
</body>
</html>
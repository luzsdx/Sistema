<?php

require('../../php/conexion.php');

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
  header("location: ../../..iniciar_sesion.php?error=debe_loguearse");
  exit;
}


$sql= "SELECT*FROM cargo";

$rs_cargo=mysqli_query($conexion,$sql);



?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Nuevo empleado</title>
</head>
<body bgcolor="orange">

  <div align="center">

    <font color="white" face="Verdana, Arial, Helvetica, sans-serif">



   <h1>Alta de empleados</h1>


    <br>

    <form method="POST" action="procesamiento/procesarAlta.php">

      <h3>Ingrese los datos del paciente</h3>
      <p>
        <label>Nombre
        <input type="text" name="nombre" required="Debe ingresar el nombre">
        </label>
      </p>
      <p>
        <label>Apellido
        <input type="text" name="apellido" required="Debe ingresar el apellido">
        </label>
      </p>
      <p>
        <label>DNI
        <input type="text" name="dni" required="Debe ingresar el dni">
        </label>
      </p>
      <p>
       <label>Fecha de Nacimiento
        <input type="date" name="fechaNaci" required="Debe ingresar la fecha de nacimiento" placeholder="
        AAAA/MM/DD">
        </label>
      </p>   
      <p>
         Cargo <select name="cboCargo">
            <?php while ($row = $rs_cargo->fetch_assoc()): ?>
              <option value="<?php echo $row['id_cargo']; ?>">
                <?php echo $row["descripcion"]; ?>
                </option>
              <?php endwhile; ?>
          </select>
      </p>
      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>
    </form>
    
  </div>

  

</body>
</html>
<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location: ../../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$table1='cargo';
$id_persona = $_POST['ID'];
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$dni = $_POST["dni"];
$fechaNac= date($_POST["fechaNaci"]);
$cargo= $_POST["cboCargo"];



// cuando agrego nueva persona estado = Activo
$estado = "Activo";

// GUARDO PERSONA
$sql = "INSERT INTO personas(`nombre`,`apellido`,`DNI`,`fechanacimiento`,`estado`) " 
  ."VALUES ('$nombre','$apellido','$dni','$fechaNac','$estado')";

// si no puedo guardar, redirecciono al formualrio con mensaje de error
if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'GUARDAR_PERSONA_ERROR';
	header("location:../listado.php?id_persona=$id_persona&mensaje=$mensaje");
	exit;
}


// obtengo el id insertado en personas
$id_persona = mysqli_insert_id($conexion);

// GUARDO PACIENTE
$sql = "INSERT INTO empleados(`id_persona`,`id_cargo`) "
 ." VALUES('$id_persona', '$cargo')";


// si no puedo guardar, redirecciono al formulario con mensaje de error
//NO N O COLOCAR, SE ESTÁ EJECUTANDO 2 VECES $rs = $conexion->query($sql) or die ($conexion->error) ;


if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'GUARDAR_EMPLEADO_ERROR';
	header("location: ../listado.php?id_persona=$id_persona&mensaje=$mensaje");
	exit;
}

$mensaje = 'GUARDAR_EMPLEADO_OK';
header("location: ../listado.php?id_persona=$id_persona&mensaje=$mensaje");

?>
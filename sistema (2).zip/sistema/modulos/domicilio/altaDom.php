<?php

require('../../php/conexion.php');

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
  header("location: ../../php/iniciar_sesion.php?error=debe_loguearse");
  exit;
}


$id_persona= $_GET["id_persona"];
/*if($id_persona==""){
  echo "dato vacio";
}else{
  echo $id_persona;
}
exit(); */

$sql= "SELECT * FROM provincia ";

$rs_provincia=mysqli_query($conexion,$sql);

$sql="SELECT * FROM ciudades";

$rs_ciudad=mysqli_query($conexion,$sql);


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Nuevo</title>
  <script type="text/javascript" src="../../funciones/consultarCombos.js"></script>
</head>
<body bgcolor="brown">

  <div align="center">

    <font color="white" face="Verdana, Arial, Helvetica, sans-serif">



   <h1>Crear domicilio</h1>

    <br>

    <form method="POST" action="procesamiento/procesarAlta.php?id_persona=<?php echo $id_persona= $_GET['id_persona'];?>">
      <input type="hidden" name="ID_per" value="<?php echo $id_persona;?>">
      <input type="hidden" name="ID_dom" value="<?php echo $id_domicilio;?>">

      <h3>Ingrese los datos del domicilio</h3>
      <p> Observación
        <input type="text" name="observacion">
      </p>
      <p>
        <label> Provincia</label>
        <select name="cboProvincia" required
         onchange="consultarCiudades(this.value)">
          <option value="" >Sin especificar</option>
          <?php while ($datosProvincia=mysqli_fetch_array($rs_provincia)){ ?>
            <option value= "<?php echo $datosProvincia['id_provincia'] ?>"> <?php echo $datosProvincia['descripcion']; ?> </option>
          <?php } ?> 
        </select>
      </p>
      <p>
        <label> Ciudad</label>
        <select name="cboCiudades" id="ciudades">
          <option value="0" >Sin especificar</option>
        </select>
      </p>
      <p>Barrio
        <input type="text" name="barrio">
      </p>
      <p>Calle
        <input type="text" name="calle">
      </p>
      <p>Altura
        <input type="text" name="altura">
      </p>
      <p>Piso
        <input type="text" name="piso">
      </p>
      <p>Torre
        <input type="text" name="torre">
      </p>
      <p>Manzana
        <input type="text" name="manzana">
      </p>
      <p>Sector/Parcela
        <input type="text" name="sector_parcela">
      </p>


      <p>
        <button type="button" onclick="window.history.go(-1); return false;">Cancelar</button> &nbsp;
        <input type="submit" value="Guardar">
      </p>


    </form>
    
  </div>

</body>
</html>
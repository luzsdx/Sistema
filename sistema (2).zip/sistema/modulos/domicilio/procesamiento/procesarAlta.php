<?php

require '../../../php/conexion.php';

session_start();

if (!isset($_SESSION["logueado"])) {
	header("location: ../../../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

$persona= $_POST['ID_per'];
$observacion= $_POST['observacion'];
$provincia= $_POST['cboProvincia'];
$ciudades=$_POST['cboCiudades']; 
$barrio = $_POST ['barrio'];
$calle = $_POST ['calle'];
$altura = $_POST ['altura'];
$piso = $_POST ['piso'];
$torre = $_POST ['torre'];
$manzana = $_POST ['manzana'];
$sector_parcela = $_POST ['sector_parcela'];

switch ('cboProvincia') {
	case '0':
		$cboCiudad=4;
		break;
	case '1':
		$cboCiudad=1;
		break;
	case '2':
		$cboCiudad=2;
		break;			
	case '3':
		$cboCiudad=3;
		break;	

}


$estado = 1;


  

//echo $sql. "<br>";

//exit();

// GUARDO DOMICILIO
/*$sql = "INSERT INTO  domicilios(`id_persona`,`observacion`,`barrio`,`calle`,`altura`,`piso`,`torre`,`manzana`,`sector_parcela`,`id_ciudad`, `estado`) "
 ."VALUES($persona, '$observacion', '$barrio', '$calle', $altura,$piso,$torre,$manzana,$sector_parcela, $ciudades, $estado) "; */

 $sql= "INSERT INTO domicilios(`id_persona`,`observacion`,`barrio`,`calle`,`altura`,`piso`,`torre`,`manzana`,`sector_parcela`,`estado`, id_ciudad) "
     ."VALUES ($persona,'$observacion', '$barrio','$calle', '$altura', '$piso', '$torre','$manzana','$sector_parcela', '$estado', $ciudades ) ";





// si no puedo guardar, redirecciono al formulario con mensaje de error



if (!mysqli_query($conexion, $sql)) {
	$mensaje = 'GUARDAR_DOMICILIO_ERROR';
	header("location: ../listado.php?id_persona=$persona&mensaje=$mensaje");
	exit;
}


$mensaje = 'GUARDAR_DOMICILIO_OK';
header("location: ../listado.php?id_persona=$persona&mensaje=$mensaje");

?>
<?php

require'../../php/conexion.php';

session_start();

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../..iniciar_sesion.php?error=debe_loguearse");
	exit;
}

if (isset($_GET['mensaje'])) {
	switch ($_GET['mensaje']) {
        case 'GUARDAR_ASISTENTE_OK':
            $mensaje = 'Asistente agregado correctamente.';
            break;

		case 'GUARDAR_ASISTENTE_ERROR':
			$mensaje = 'Ha ocurrido un error al intentar crear el asistente.';
			break;
	}
}


$sql = "SELECT personas. id_persona, `nombre`,`apellido`, profesion.`descripcion` AS 'profesion', especialidad.`descripcion` AS 'especialidad', profesionales.`id_profesional`,`matricula`"
."FROM profesionales "
."inner join personas on profesionales.`id_persona`= personas.`id_persona` "
."inner join profesion on profesionales.`id_profesion`= profesion.`id_profesion` "
."inner join especialidad on profesionales.`id_especialidad` = especialidad.`id_especialidad`";


//descripcion contacto=  contacto
$rs = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Profesionales</title>
</head>
<body bgcolor="orange">
	<?php require '../../php/menu.php'; ?>
	<div align='center'>
		<h1><b>Listado de profesionales</b></h1>

    	<?php if (isset($mensaje)): ?>
    		<h3><font color="red"><?php echo $mensaje; ?></font></h3>
    	<?php endif; ?>

		<p><a href="alta.php">Nuevo profesional</a></p>
		<br>
		<table border="1" cellpadding="2" cellspacing="0">
			<thead>
					<th>ID Profesional</th>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>Profesión</th>
					<th>Especialidad</th>
					<th>Matrícula</th>
					<th>Contacto</th>
					<th>Domicilio</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php while ($row = $rs->fetch_assoc()): ?>
					<tr>
						<td><?php echo utf8_encode($row ['id_profesional']) ?></td>
						<td><?php echo utf8_encode($row['nombre']); ?> </td>
						<td> <?php echo utf8_encode($row['apellido']); ?> </td>
						<td> <?php echo utf8_encode($row['profesion']); ?> </td>
						<td> <?php echo utf8_encode($row['especialidad']); ?> </td>
						<td> <?php echo utf8_encode($row['matricula']); ?> </td>
						<td> <a href="../contacto/listado.php?id_persona=<?php echo $row['id_persona']; ?> ">Ver</a> </td>
						<td> <a href="../domicilio/listado.php?id_persona=<?php echo $row['id_persona']; ?>">Ver</a> </td>

						<td><a href="editar.php?id_persona=<?php echo $row['id_persona']; ?>">
							    Editar
							</a> | 
							<a href="procesamiento/procesarBaja.php?id_persona=<?php echo $row['id_persona']; ?>" onclick="return confirm('¿Estas seguro de que desea eliminar el paciente?' )">
							    Eliminar
							</a>
						</td>
					</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
	</div>

<script src="../../jquery-3.4.1.min.js"></script>
<script src="../../bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script> 

</body>
</html>
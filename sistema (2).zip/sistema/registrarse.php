<?php
require('php/conexion.php');

$sql= "SELECT * FROM especialidad";
$rs_especialidad=mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/font.css">
	<link rel="stylesheet" type="text/css" href="/sistema/css/cuenta.css">
</head>
<body class="cuerpo">
	<div class="container ">
		<div class="row d-flow justify-content-center">
			<div class="col-md-6 col-sm-12 shadow-lg rounded-lg bg-white pr-5 pl-5 pb-4 pt-4 m-5 ">
				<form id="Regf" action="php/procesar_r.php" method="POST" accept-charset="utf-8">
					<h1 class="text-center"> Ingrese sus datos</h1>
					<div class=" form-group">
							<input class=" casilla bg-white form-control"  type="text" id="usuario" name="usuario" placeholder="Ingrese su usuario" >
				    </div>
					<div class=" form-group">
							<input class=" casilla bg-white form-control"  type="text" id="nombre" name="nombre" placeholder="Ingrese su nombre">
				    </div>
					<div  class=" form-group">
							<input  class="casilla bg-white form-control" type="text" name="apellido" placeholder="Ingrese su apellido">
				    </div>
					<div class=" form-group">
							<input  class=" casilla bg-white form-control" type="date" name="fnac" placeholder="Seleccione su fecha de nacimiento">
					</div>
					<div class=" form-group">
							<input class=" casilla bg-white form-control" type="text" name="matricula" placeholder="Ingrese su matrícula">
					</div>
					<div class=" form-group ">
						<select class="casilla form-control" name="cboespecialidad"
						>
						<option>Seleccione especialidad</option>
           					 <?php while ($row = $rs_especialidad->fetch_assoc()): ?>
            				  <option value="<?php echo $row['id_especialidad']; ?>">
              				  <?php echo utf8_encode ($row["descripcion"]); 
              				  ?>
              				  </option>
             				 <?php endwhile; ?>
         				 </select>
				    </div>
					<div class="form-group">
							<input  class="casilla form-control bg-white" type="password" id="pass" name="pass" placeholder="Ingrese su contraseña">
					</div>
					<div class=" form-group">
							<input  class="casilla form-control bg-white" type="password" id="confir_pass" name="confir_pass" placeholder="Confirme contraseña">
					</div> 
					<button id="deshabilitar" class="signup" type="submit">Registrarse</button>
				</form>
			</div>
		</div>		
	</div>




	
</body>



<script src="jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script src="bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#Regf").validate({
					rules: {
				usuario: {
					required: true,
					minlength: 5
				},
				nombre: {
					required: true,
					minlength: 3
				},
				apellido: {
					required:true,
					minlength: 5
				},
				fnac: "required",
				matricula:{
					required:true,
					minlength:3
				},
				pass: {
					required: true,
					minlength: 5,
				},
				confir_pass: {
					required:true,
					minlength:5,
					equalTo: "#pass"
				}
			},
			messages: {
				usuario: {
					required: "Por favor, ingrese un usuario",
					minlength: "Su usuario debe tener al menos 5 caracteres"
				},
				nombre: {
					required: "Por favor, ingrese su nombre",
					minlength: "Su nombre debe tener al menos 3 caracteres"
				},
				apellido: {
					required: "Por favor, ingrese su apellido",
					minlength: "Su apellido debe tener al menos 3 caracteres"
				},
				fnac: "Por favor, seleccione su fecha de nacimiento",
				matricula: {
					required:"Por favor, ingrese su matrícula",
					minlength: "Su matrícula debe tener al menos 3 caracteres"
				},
				pass: {
					required: "Por favor, ingrese su contraseña",
					minlength:"Su contraseña debe tener al menos 5 caracteres"
				},
				confir_pass: {
					required: "Por favor, confirme su contraseña",
					minlength:"Su contraseña debe tener al menos 5 caracteres",
					equalTo:"Asegúrese de que los campos Contraseña y Confirme contraseña coincidan." 					
				}
			}	

		});	
});
</script>

</html>
<!DOCTYPE >
<html>
<head>
	<title></title>
</head>
<body>

	<?php require 'php/menu.php'; ?>

	<a href="php/cerrar_sesion.php">Cerrar sesion</a>	

</body>
</html>
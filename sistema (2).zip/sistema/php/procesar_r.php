<?php

require 'conexion.php';
require '../funciones/obtener_modulos.php';

$user= $_POST['usuario'];
$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$nacimiento= date($_POST['fnac']);
$matricula=$_POST['matricula'];
$pass= $_POST['pass'];
$especialidad = $_POST['cboespecialidad'];

$sql="INSERT INTO personas(nombre, apellido, fechanacimiento)"
. "VALUES ('$nombre', '$apellido', '$nacimiento')";


if (!mysqli_query($conexion, $sql)){
	$mensaje="GUARDAR_PERSONA_ERROR";
	header('../registrarse.php?mensaje=$mensaje');
	exit;
}

$id_persona=mysqli_insert_id($conexion);

$id_perfil = 3;

// fin perfil

$sql= "INSERT INTO usuarios (username, password, id_persona, id_perfil)"
."VALUES ('$user', '$pass', '$id_persona', $id_perfil)";


if (!mysqli_query($conexion, $sql)) {
	$mensaje="GUARDAR_USUARIO_ERROR";
	header('../registrarse.php?mensaje=$mensaje');
	exit;
}


$sql="INSERT INTO profesionales(id_persona, matricula, id_especialidad)"
. "VALUES ('$id_persona', '$matricula', $especialidad)";

if(!mysqli_query($conexion, $sql)){
	$mensaje="GUARDAR_PROFESIONAL_ERROR";
	header('../registrarse.php?mensaje=$mensaje');
}

session_start();
$_SESSION['logueado'] = true;
$_SESSION['usuario'] = $nombre . ', ' . $apellido;
$_SESSION['id_persona'] = $id_persona;

// Llamada a la función para obtener módulos.
// Esta función develve un array con el id y descripción de los módulos.
$modulos = obtener_modulos($id_persona);

// Este array de módulos lo asigno a una variable de sesión.
$_SESSION["modulos"] = $modulos;

// Luego de crear la sesión debemos redireccionar
header('location: ../dashboard.php');

?>
<?php

// session_status Devuelve el estado de la sesión actual 
$status = session_status();

//php_session_none si las sesiones estan habilitadas, pero no existe ninguna 
if ($status == PHP_SESSION_NONE) {
	//y si el estado de la sesión esta habiltada pero no existe, entonces inicia una nueva sesion
    session_start();
}

// Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
if (!isset($_SESSION["logueado"])) {
	header("location: ../iniciar_sesion.php?error=debe_loguearse");
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" type="text/css" href="/sistema/css/font.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="/sistema/css/menu.css">

</head>
<body>


	<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #4e5b63">
  <a class="navbar-brand logo" href="#">LOGO</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav ml-auto">
    	<li class="nav-item active">
        <a  class="nav-link modulo" style="color:white" href="/sistema/dashboard.php" >Inicio</a>
      </li>
    	<?php foreach ($_SESSION['modulos'] as $modulo): ?>
      <li class="nav-item active">
        <a class="nav-link modulo" style="color: white"  href="/sistema/modulos/<?php echo $modulo['directorio']; ?>/listado.php"><?php echo utf8_encode($modulo['descripcion']); ?> <span class="sr-only">(current)</span></a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      	<?php endforeach; ?>
    </ul>
  </div>
</nav>

<script src="/sistema/jquery-3.4.1.min.js"></script>
<script src="/sistema/bootstrap-4.4.1-dist/js/bootstrap.bundle.js"></script> 

</body>
</html>
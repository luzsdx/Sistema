<?php

require'conexion.php';

$usuario= $_POST['usuario'];

$buscarUser="SELECT * FROM usuarios where username = '$usuario'";

$rs = mysqli_query($conexion,$buscarUser);

$cantidad= mysqli_num_rows($rs);



  if ( $cantidad==1 ) {
    $response = array( 'valid' => false, 'message' => 'Este usuario ya esta ocupado!' );
  } else {
    $response = array( 'valid' => true );
  }

mysqli_close($conexion);

echo json_encode($response);

?>